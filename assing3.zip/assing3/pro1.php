<?php
    $servername="localhost";
    $username="root";
    $password="";
    $dbname="feedback form";



    $conn=new mysqli($servername,$username,$passaword,$dbname);

    if($conn->connect_error)
    {
        die("connection fail");
    }
    if(isset($_POST["submit"])){
    $Firstname=$_POST['Firstname'];
    $Lastname=$_POST['Lastname'];
    $Emailid=$_POST['Emailid'];  
    $ContactNo=$_POST['ContactNo']; 
    $FeedBack=$_POST['FeedBack'];

    $sql="INSERT INTO `feedback-form`(`Firstname`, `Lastname`, `Emailid`, `ContactNo`, `FeedBack`) VALUES ('$Firstname`, `$Lastname`, `$Emailid`, `$ContactNo`, `$FeedBack')";

    if($conn->query($sql)==true)
    {
        echo"new record added";
    }
    else{
        echo"error";
    }
    $conn->close();
}
    ?>